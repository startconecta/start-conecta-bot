# Pacote de configurações do sistema

