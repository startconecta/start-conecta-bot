"""
Configurações do Fluxo de Atendimento Automatizado
Atendente Theo - START Conecta
"""

import os
from datetime import datetime, time

# Configurações do Z-API
ZAPI_CONFIG = {
    'instance_id': os.getenv('ZAPI_INSTANCE_ID', 'your_instance_id'),
    'token': os.getenv('ZAPI_TOKEN', 'your_token'),
    'base_url': None  # Será definido dinamicamente
}

# Configurações da empresa
EMPRESA_CONFIG = {
    'nome': 'START Conecta',
    'telefone': '(11) 99999-9999',
    'email': 'contato@startconecta.com.br',
    'email_comercial': 'comercial@startconecta.com.br',
    'website': 'www.startconecta.com.br',
    'portfolio_url': 'www.startconecta.com.br/portfolio'
}

# Horários de funcionamento
HORARIOS = {
    'segunda_sexta': {'inicio': time(8, 0), 'fim': time(18, 0)},
    'sabado': {'inicio': time(8, 0), 'fim': time(12, 0)},
    'domingo': 'fechado',
    'feriados': 'fechado'
}

# Configurações do atendente virtual
ATENDENTE_CONFIG = {
    'nome': 'Theo',
    'emoji': '🤖',
    'saudacao_personalizada': True,
    'timeout_resposta': 30,  # segundos
    'max_tentativas': 3
}

# Palavras-chave para ativação do fluxo
PALAVRAS_ATIVACAO = [
    'oi', 'olá', 'ola', 'hello', 'hi',
    'menu', 'inicio', 'começar', 'comecar', 'start',
    'ajuda', 'help', 'atendimento', 'suporte'
]

# Respostas automáticas por categoria
RESPOSTAS_AUTOMATICAS = {
    'agradecimento': [
        'Obrigado por entrar em contato com a START Conecta! 😊',
        'Agradecemos seu interesse em nossos serviços! 🙏',
        'Muito obrigado pelo contato! Estamos aqui para ajudar! ✨'
    ],
    'despedida': [
        'Até logo! Estaremos sempre aqui quando precisar! 👋',
        'Obrigado pelo contato! Tenha um ótimo dia! 🌟',
        'Foi um prazer atendê-lo! Volte sempre! 😊'
    ],
    'fora_horario': [
        f"""🕐 *Fora do Horário de Atendimento*

Olá! Nosso atendimento está fechado no momento.

📅 *Horários de Funcionamento:*
Segunda a Sexta: 8h às 18h
Sábado: 8h às 12h

📱 *Para urgências:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}

Deixe sua mensagem que retornaremos assim que possível! 📝"""
    ]
}

# Fluxo principal de atendimento
FLUXO_ATENDIMENTO = {
    'boas_vindas': {
        'mensagem': f"""🤖 Olá! Eu sou o *{ATENDENTE_CONFIG['nome']}*, seu assistente virtual da {EMPRESA_CONFIG['nome']}!

Como posso te ajudar hoje? Escolha uma das opções:

1️⃣ Informações sobre nossos serviços
2️⃣ Suporte técnico
3️⃣ Falar com um atendente humano
4️⃣ Horário de funcionamento
5️⃣ Solicitar orçamento

Digite o número da opção desejada.""",
        'opcoes': ['1', '2', '3', '4', '5']
    },
    
    'servicos': {
        'mensagem': f"""📋 *Nossos Serviços - {EMPRESA_CONFIG['nome']}*

🌐 *Desenvolvimento Web*
• Sites institucionais responsivos
• E-commerce completo
• Sistemas web personalizados
• Landing pages otimizadas

📱 *Aplicativos Mobile*
• Apps Android e iOS nativos
• Apps híbridos (React Native)
• PWA (Progressive Web Apps)

☁️ *Soluções em Nuvem*
• Migração para cloud (AWS, Azure)
• Infraestrutura como serviço
• DevOps e CI/CD

🔧 *Consultoria em TI*
• Análise de sistemas existentes
• Otimização de processos
• Arquitetura de software
• Code review e refatoração

💡 *Automação e IA*
• Chatbots inteligentes
• Automação de processos
• Integração de APIs

Para mais informações, digite:
*ORCAMENTO* - Para solicitar um orçamento
*PORTFOLIO* - Para ver nossos trabalhos
*CONTATO* - Para falar com especialista
*VOLTAR* - Para voltar ao menu principal""",
        'opcoes': ['ORCAMENTO', 'PORTFOLIO', 'CONTATO', 'VOLTAR']
    },
    
    'suporte': {
        'mensagem': f"""🛠️ *Suporte Técnico - {EMPRESA_CONFIG['nome']}*

Como posso te ajudar com suporte?

1️⃣ Problema com site/sistema
2️⃣ Dúvidas sobre hospedagem
3️⃣ Configuração de e-mail
4️⃣ Problemas de performance
5️⃣ Backup e recuperação
6️⃣ Outros problemas técnicos
7️⃣ Voltar ao menu principal

Digite o número da opção:""",
        'opcoes': ['1', '2', '3', '4', '5', '6', '7']
    },
    
    'atendente_humano': {
        'mensagem': f"""👨‍💼 *Atendimento Humano*

Entendi que você precisa falar com um de nossos especialistas!

📞 *Horário de Atendimento:*
Segunda a Sexta: 8h às 18h
Sábado: 8h às 12h

📱 *Contatos Diretos:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}
Comercial: {EMPRESA_CONFIG['email_comercial']}

🕐 *Fora do horário?*
Deixe sua mensagem que retornaremos assim que possível!

💬 *Ou continue aqui mesmo!*
Posso ajudar com informações básicas sobre nossos serviços.

Digite *VOLTAR* para retornar ao menu principal.""",
        'opcoes': ['VOLTAR']
    },
    
    'horario': {
        'mensagem': f"""🕐 *Horário de Funcionamento - {EMPRESA_CONFIG['nome']}*

📅 *Segunda a Sexta-feira:*
8h às 18h

📅 *Sábado:*
8h às 12h

📅 *Domingo:*
Fechado

⚡ *Atendimento de Emergência:*
Disponível 24h para clientes com contrato de suporte premium

📞 *Contato:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}
Website: {EMPRESA_CONFIG['website']}

🌍 *Atendemos todo o Brasil remotamente!*

Digite *VOLTAR* para retornar ao menu principal.""",
        'opcoes': ['VOLTAR']
    },
    
    'orcamento': {
        'mensagem': f"""💰 *Solicitação de Orçamento - {EMPRESA_CONFIG['nome']}*

Para elaborarmos um orçamento personalizado e preciso, preciso de algumas informações:

📝 *Por favor, me informe:*
1️⃣ Tipo de projeto (site, app, sistema, consultoria)
2️⃣ Funcionalidades principais desejadas
3️⃣ Prazo esperado para entrega
4️⃣ Orçamento disponível (opcional)
5️⃣ Sua empresa/segmento de atuação

💬 *Pode descrever tudo em uma mensagem ou*
📞 *Falar diretamente com nosso comercial:*

WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email_comercial']}

⚡ *Resposta em até 24h úteis!*

Digite *VOLTAR* para retornar ao menu.""",
        'opcoes': ['VOLTAR']
    }
}

# Respostas para suporte técnico específico
SUPORTE_RESPOSTAS = {
    '1': f"""🔧 *Problema com Site/Sistema*

Para te ajudar melhor, preciso de algumas informações:

📋 *Descreva o problema:*
• Qual erro está aparecendo?
• Quando começou a acontecer?
• Em que página/funcionalidade?
• Qual navegador está usando?

📞 *Suporte Urgente:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}

⚡ *Clientes com contrato de suporte têm atendimento prioritário!*

Digite *VOLTAR* para retornar ao menu.""",
    
    '2': f"""🌐 *Dúvidas sobre Hospedagem*

Como posso ajudar com hospedagem?

📊 *Serviços de Hospedagem:*
• Hospedagem compartilhada
• VPS (Servidor Virtual)
• Cloud hosting
• Hospedagem dedicada

🔧 *Suporte inclui:*
• Configuração de domínio
• Certificado SSL gratuito
• Backup automático
• Monitoramento 24/7

📞 *Fale com nosso especialista:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}

Digite *VOLTAR* para retornar ao menu.""",
    
    '3': f"""📧 *Configuração de E-mail*

Precisa de ajuda com e-mail corporativo?

⚙️ *Configuramos para você:*
• E-mail profissional (@suaempresa.com.br)
• Configuração em celular/computador
• Outlook, Gmail, Thunderbird
• Sincronização entre dispositivos

📱 *Configuração remota disponível!*

📞 *Suporte especializado:*
WhatsApp: {EMPRESA_CONFIG['telefone']}
E-mail: {EMPRESA_CONFIG['email']}

💡 *Dica: Tenha em mãos suas credenciais de acesso*

Digite *VOLTAR* para retornar ao menu."""
}

# Configurações de log
LOG_CONFIG = {
    'ativar_logs': True,
    'nivel_log': 'INFO',
    'arquivo_log': 'logs/atendimento.log',
    'formato_log': '%(asctime)s - %(levelname)s - %(message)s'
}

def get_saudacao_personalizada(nome_contato=""):
    """Retorna uma saudação personalizada baseada no horário"""
    agora = datetime.now()
    hora = agora.hour
    
    if 5 <= hora < 12:
        periodo = "Bom dia"
    elif 12 <= hora < 18:
        periodo = "Boa tarde"
    else:
        periodo = "Boa noite"
    
    if nome_contato:
        return f"{periodo}, {nome_contato}!"
    else:
        return f"{periodo}!"

def esta_no_horario_funcionamento():
    """Verifica se está no horário de funcionamento"""
    agora = datetime.now()
    dia_semana = agora.weekday()  # 0 = segunda, 6 = domingo
    hora_atual = agora.time()
    
    if dia_semana < 5:  # Segunda a sexta
        horario = HORARIOS['segunda_sexta']
        return horario['inicio'] <= hora_atual <= horario['fim']
    elif dia_semana == 5:  # Sábado
        horario = HORARIOS['sabado']
        return horario['inicio'] <= hora_atual <= horario['fim']
    else:  # Domingo
        return False

def get_zapi_base_url():
    """Retorna a URL base do Z-API"""
    instance_id = ZAPI_CONFIG['instance_id']
    token = ZAPI_CONFIG['token']
    return f"https://api.z-api.io/instances/{instance_id}/token/{token}"

