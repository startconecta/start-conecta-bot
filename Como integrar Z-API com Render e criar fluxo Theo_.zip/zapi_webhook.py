from flask import Blueprint, request, jsonify
import requests
import json
import os
import logging
from datetime import datetime
from src.config.atendimento_config import (
    ZAPI_CONFIG, EMPRESA_CONFIG, FLUXO_ATENDIMENTO, SUPORTE_RESPOSTAS,
    PALAVRAS_ATIVACAO, RESPOSTAS_AUTOMATICAS, LOG_CONFIG,
    get_saudacao_personalizada, esta_no_horario_funcionamento, get_zapi_base_url
)

zapi_bp = Blueprint('zapi', __name__)

# Configurações do Z-API (agora usando o arquivo de config)
ZAPI_INSTANCE_ID = ZAPI_CONFIG['instance_id']
ZAPI_TOKEN = ZAPI_CONFIG['token']
ZAPI_BASE_URL = get_zapi_base_url()

# Configurar logging
if LOG_CONFIG['ativar_logs']:
    logging.basicConfig(
        level=getattr(logging, LOG_CONFIG['nivel_log']),
        format=LOG_CONFIG['formato_log']
    )

# Fluxo de atendimento do Atendente Theo
ATENDIMENTO_FLUXO = {
    'boas_vindas': {
        'mensagem': """🤖 Olá! Eu sou o *Theo*, seu assistente virtual da START Conecta!

Como posso te ajudar hoje? Escolha uma das opções:

1️⃣ Informações sobre nossos serviços
2️⃣ Suporte técnico
3️⃣ Falar com um atendente humano
4️⃣ Horário de funcionamento

Digite o número da opção desejada.""",
        'opcoes': ['1', '2', '3', '4']
    },
    'servicos': {
        'mensagem': """📋 *Nossos Serviços - START Conecta*

🌐 *Desenvolvimento Web*
- Sites institucionais
- E-commerce
- Sistemas web personalizados

📱 *Aplicativos Mobile*
- Apps Android e iOS
- Apps híbridos

☁️ *Soluções em Nuvem*
- Migração para cloud
- Infraestrutura como serviço

🔧 *Consultoria em TI*
- Análise de sistemas
- Otimização de processos

Para mais informações, digite:
*ORCAMENTO* - Para solicitar um orçamento
*PORTFOLIO* - Para ver nossos trabalhos
*VOLTAR* - Para voltar ao menu principal""",
        'opcoes': ['ORCAMENTO', 'PORTFOLIO', 'VOLTAR']
    },
    'suporte': {
        'mensagem': """🛠️ *Suporte Técnico - START Conecta*

Como posso te ajudar com suporte?

1️⃣ Problema com site/sistema
2️⃣ Dúvidas sobre hospedagem
3️⃣ Configuração de e-mail
4️⃣ Outros problemas técnicos
5️⃣ Voltar ao menu principal

Digite o número da opção:""",
        'opcoes': ['1', '2', '3', '4', '5']
    },
    'atendente_humano': {
        'mensagem': """👨‍💼 *Atendimento Humano*

Entendi que você precisa falar com um de nossos especialistas!

📞 *Horário de Atendimento:*
Segunda a Sexta: 8h às 18h
Sábado: 8h às 12h

📱 *Contatos Diretos:*
WhatsApp: (11) 99999-9999
E-mail: contato@startconecta.com.br

🕐 *Fora do horário?*
Deixe sua mensagem que retornaremos assim que possível!

Digite *VOLTAR* para retornar ao menu principal.""",
        'opcoes': ['VOLTAR']
    },
    'horario': {
        'mensagem': """🕐 *Horário de Funcionamento - START Conecta*

📅 *Segunda a Sexta-feira:*
8h às 18h

📅 *Sábado:*
8h às 12h

📅 *Domingo:*
Fechado

⚡ *Atendimento de Emergência:*
Disponível 24h para clientes com contrato de suporte premium

📞 *Contato:*
WhatsApp: (11) 99999-9999
E-mail: contato@startconecta.com.br

Digite *VOLTAR* para retornar ao menu principal.""",
        'opcoes': ['VOLTAR']
    }
}

def enviar_mensagem_zapi(numero, mensagem):
    """Envia mensagem via Z-API"""
    try:
        url = f"{ZAPI_BASE_URL}/send-text"
        payload = {
            "phone": numero,
            "message": mensagem
        }
        headers = {
            'Content-Type': 'application/json'
        }
        
        response = requests.post(url, json=payload, headers=headers)
        return response.json()
    except Exception as e:
        print(f"Erro ao enviar mensagem: {e}")
        return None

def processar_mensagem(numero, mensagem, nome_contato=""):
    """Processa a mensagem recebida e retorna a resposta apropriada"""
    mensagem_lower = mensagem.lower().strip()
    
    # Mensagens de boas-vindas ou menu principal
    if mensagem_lower in ['oi', 'olá', 'ola', 'menu', 'inicio', 'começar', 'comecar', 'start']:
        return ATENDIMENTO_FLUXO['boas_vindas']['mensagem']
    
    # Opções do menu principal
    elif mensagem_lower == '1':
        return ATENDIMENTO_FLUXO['servicos']['mensagem']
    elif mensagem_lower == '2':
        return ATENDIMENTO_FLUXO['suporte']['mensagem']
    elif mensagem_lower == '3':
        return ATENDIMENTO_FLUXO['atendente_humano']['mensagem']
    elif mensagem_lower == '4':
        return ATENDIMENTO_FLUXO['horario']['mensagem']
    
    # Opções do menu de serviços
    elif mensagem_lower == 'orcamento':
        return """💰 *Solicitação de Orçamento*

Para elaborarmos um orçamento personalizado, preciso de algumas informações:

📝 Por favor, me informe:
1. Tipo de projeto (site, app, sistema)
2. Funcionalidades desejadas
3. Prazo esperado
4. Orçamento disponível (opcional)

Ou se preferir, fale diretamente com nosso comercial:
📞 WhatsApp: (11) 99999-9999
📧 E-mail: comercial@startconecta.com.br

Digite *VOLTAR* para retornar ao menu."""
    
    elif mensagem_lower == 'portfolio':
        return """🎨 *Nosso Portfólio*

Confira alguns de nossos trabalhos:

🌐 *Sites Desenvolvidos:*
• www.exemplo1.com.br
• www.exemplo2.com.br
• www.exemplo3.com.br

📱 *Apps Publicados:*
• App Delivery Local
• Sistema de Gestão Empresarial
• E-commerce Mobile

📁 *Portfólio Completo:*
www.startconecta.com.br/portfolio

📞 *Quer saber mais?*
WhatsApp: (11) 99999-9999

Digite *VOLTAR* para retornar ao menu."""
    
    # Voltar ao menu principal
    elif mensagem_lower == 'voltar':
        return ATENDIMENTO_FLUXO['boas_vindas']['mensagem']
    
    # Opções do suporte técnico
    elif mensagem_lower == '5':
        return ATENDIMENTO_FLUXO['boas_vindas']['mensagem']
    
    # Mensagem padrão para entradas não reconhecidas
    else:
        return f"""❓ Desculpe, não entendi sua mensagem: "{mensagem}"

Para melhor atendimento, use uma das opções do menu:

1️⃣ Informações sobre nossos serviços
2️⃣ Suporte técnico  
3️⃣ Falar com um atendente humano
4️⃣ Horário de funcionamento

Ou digite *MENU* para ver todas as opções novamente."""

@zapi_bp.route('/webhook', methods=['POST'])
def webhook_zapi():
    """Webhook para receber mensagens do Z-API"""
    try:
        data = request.get_json()
        
        # Log da mensagem recebida
        print(f"Webhook recebido: {json.dumps(data, indent=2)}")
        
        # Verifica se é uma mensagem de texto
        if data.get('type') == 'ReceivedCallback':
            message_data = data.get('data', {})
            
            # Extrai informações da mensagem
            numero = message_data.get('phone', '')
            mensagem = message_data.get('body', {}).get('text', '')
            nome_contato = message_data.get('senderName', '')
            
            # Processa apenas mensagens de texto não vazias
            if mensagem and numero:
                # Gera resposta baseada no fluxo de atendimento
                resposta = processar_mensagem(numero, mensagem, nome_contato)
                
                # Envia resposta via Z-API
                resultado = enviar_mensagem_zapi(numero, resposta)
                
                # Log da resposta enviada
                print(f"Resposta enviada para {numero}: {resposta}")
                print(f"Resultado Z-API: {resultado}")
                
                return jsonify({
                    'status': 'success',
                    'message': 'Mensagem processada com sucesso',
                    'response_sent': resposta
                }), 200
        
        return jsonify({'status': 'ignored', 'message': 'Tipo de mensagem não processado'}), 200
        
    except Exception as e:
        print(f"Erro no webhook: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@zapi_bp.route('/send-message', methods=['POST'])
def send_message():
    """Endpoint para enviar mensagens manualmente"""
    try:
        data = request.get_json()
        numero = data.get('phone')
        mensagem = data.get('message')
        
        if not numero or not mensagem:
            return jsonify({'error': 'Phone and message are required'}), 400
        
        resultado = enviar_mensagem_zapi(numero, mensagem)
        
        if resultado:
            return jsonify({
                'status': 'success',
                'message': 'Mensagem enviada com sucesso',
                'result': resultado
            }), 200
        else:
            return jsonify({'error': 'Falha ao enviar mensagem'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@zapi_bp.route('/status', methods=['GET'])
def status():
    """Endpoint para verificar status da integração"""
    return jsonify({
        'status': 'active',
        'service': 'Z-API Integration',
        'timestamp': datetime.now().isoformat(),
        'instance_id': ZAPI_INSTANCE_ID,
        'webhook_url': request.host_url + 'api/zapi/webhook'
    }), 200

@zapi_bp.route('/test', methods=['GET'])
def test():
    """Endpoint de teste"""
    return jsonify({
        'message': 'Z-API Integration is working!',
        'timestamp': datetime.now().isoformat()
    }), 200

